"""
Loan Approval Prediction API (Experiment 6, carried into Experiment 7's CI/CD pipeline).
"""
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model.pkl"

model = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global model
    if not MODEL_PATH.exists():
        raise RuntimeError(f"Model file not found at {MODEL_PATH}")
    model = joblib.load(MODEL_PATH)
    yield


app = FastAPI(
    title="Loan Approval Prediction API",
    description="Serves the loan-approval classifier; CI/CD wired up in Experiment 7.",
    version="1.0.0",
    lifespan=lifespan,
)


class LoanApplication(BaseModel):
    age: int = Field(..., ge=18, le=100)
    dependents: int = Field(..., ge=0, le=10)
    income: float = Field(..., gt=0)
    loan_amount: float = Field(..., gt=0)
    loan_term: int = Field(..., gt=0)
    cibil_score: int = Field(..., ge=300, le=900)
    debt_to_income_ratio: float = Field(..., ge=0)
    monthly_income: float = Field(..., gt=0)
    approx_monthly_installment: float = Field(..., ge=0)
    high_dependents_flag: int = Field(..., ge=0, le=1)
    gender: Literal["Male", "Female"] = "Male"
    education: Literal["Graduate", "Not Graduate", "Bachelor", "Master"] = "Graduate"
    employment_status: Literal["Salaried", "Self-Employed", "Unemployed"] = "Salaried"
    housing_type: Literal["Owned", "Rented", "Mortgage"] = "Owned"
    area_type: Literal["Urban", "Semiurban", "Rural"] = "Urban"
    loan_intent: Literal[
        "HOME", "EDUCATION", "PERSONAL", "DEBTCONSOLIDATION", "MEDICAL", "VENTURE"
    ] = "PERSONAL"


class PredictionResponse(BaseModel):
    loan_status: str
    approval_probability: float
    rejection_probability: float


@app.get("/")
def root():
    return {"status": "ok", "message": "Loan Approval Prediction API is running. See /docs for usage."}


@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": model is not None}


@app.post("/predict", response_model=PredictionResponse)
def predict(application: LoanApplication):
    if model is None:
        raise HTTPException(status_code=503, detail="Model is not loaded")
    row = pd.DataFrame([application.dict()])
    proba = model.predict_proba(row)[0]
    reject_p, approve_p = float(proba[0]), float(proba[1])
    status = "Approved" if approve_p >= 0.5 else "Rejected"
    return PredictionResponse(
        loan_status=status,
        approval_probability=round(approve_p, 4),
        rejection_probability=round(reject_p, 4),
    )
