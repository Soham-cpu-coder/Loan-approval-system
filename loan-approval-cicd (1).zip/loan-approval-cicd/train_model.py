"""
Experiment 7 - CI/CD Pipeline
Regenerates the same synthetic loan-approval dataset and RandomForest
pipeline used in Experiment 6, so the API/tests/CI pipeline in this
experiment have a real, working model artifact to operate on.
"""
import numpy as np
import pandas as pd
import joblib
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score
import json

RNG = np.random.default_rng(42)
N = 7461

BASE_DIR = Path(__file__).resolve().parent

genders = RNG.choice(["Male", "Female"], N, p=[0.7, 0.3])
educations = RNG.choice(["Graduate", "Not Graduate", "Bachelor", "Master"], N)
employment = RNG.choice(["Salaried", "Self-Employed", "Unemployed"], N, p=[0.55, 0.35, 0.10])
housing = RNG.choice(["Owned", "Rented", "Mortgage"], N)
area = RNG.choice(["Urban", "Semiurban", "Rural"], N)
intent = RNG.choice(["HOME", "EDUCATION", "PERSONAL", "DEBTCONSOLIDATION", "MEDICAL", "VENTURE"], N)

age = RNG.integers(21, 65, N)
dependents = RNG.integers(0, 6, N)
income = RNG.lognormal(mean=13.2, sigma=0.5, size=N)
loan_amount = RNG.lognormal(mean=12.7, sigma=0.6, size=N)
loan_term = RNG.choice([12, 24, 36, 48, 60, 84], N)
cibil_score = RNG.integers(300, 901, N)
monthly_income = income / 12
approx_monthly_installment = loan_amount / loan_term
debt_to_income_ratio = np.clip(approx_monthly_installment / (monthly_income + 1), 0, 3)
high_dependents_flag = (dependents >= 3).astype(int)

df = pd.DataFrame({
    "age": age, "dependents": dependents, "income": income,
    "loan_amount": loan_amount, "loan_term": loan_term, "cibil_score": cibil_score,
    "debt_to_income_ratio": debt_to_income_ratio, "monthly_income": monthly_income,
    "approx_monthly_installment": approx_monthly_installment,
    "high_dependents_flag": high_dependents_flag,
    "gender": genders, "education": educations, "employment_status": employment,
    "housing_type": housing, "area_type": area, "loan_intent": intent,
})

score = (
    0.0000025 * income - 0.0000020 * loan_amount + 0.004 * cibil_score
    - 1.8 * debt_to_income_ratio - 0.15 * dependents
    + (employment == "Unemployed") * -1.5
    + RNG.normal(0, 1.0, N)
)
prob = 1 / (1 + np.exp(-(score - score.mean()) / score.std()))
df["loan_status"] = (prob >= 0.5).astype(int)  # 1 = Approved, 0 = Rejected

numeric_features = [
    "age", "dependents", "income", "loan_amount", "loan_term",
    "cibil_score", "debt_to_income_ratio", "monthly_income",
    "approx_monthly_installment", "high_dependents_flag",
]
categorical_features = [
    "gender", "education", "employment_status", "housing_type",
    "area_type", "loan_intent",
]

X = df[numeric_features + categorical_features]
y = df["loan_status"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

preprocessor = ColumnTransformer([
    ("num", StandardScaler(), numeric_features),
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
])

clf = RandomForestClassifier(n_estimators=300, max_depth=8, min_samples_leaf=20, random_state=42)
pipeline = Pipeline([("preprocessor", preprocessor), ("classifier", clf)])
pipeline.fit(X_train, y_train)

test_pred = pipeline.predict(X_test)
test_proba = pipeline.predict_proba(X_test)[:, 1]
acc = accuracy_score(y_test, test_pred)
auc = roc_auc_score(y_test, test_proba)

Path(BASE_DIR / "app").mkdir(exist_ok=True)
joblib.dump(pipeline, BASE_DIR / "app" / "model.pkl")
df.to_csv(BASE_DIR / "Cleaned_Loan_Dataset.csv", index=False)

metrics = {"rows": N, "train_rows": len(X_train), "test_rows": len(X_test),
           "test_accuracy": round(acc, 4), "test_roc_auc": round(auc, 4)}
with open(BASE_DIR / "app" / "metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)

print(json.dumps(metrics, indent=2))
print("Saved model to app/model.pkl and dataset to Cleaned_Loan_Dataset.csv")
