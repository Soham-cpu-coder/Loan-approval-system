"""
Experiment 7 - test job for the CI pipeline.
Exercises the /health and /predict endpoints of the Experiment 6 API
using FastAPI's TestClient, so these same assertions run identically
on a laptop and inside GitHub Actions.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.main import app  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


APPROVE_LEANING = {
    "age": 34, "dependents": 1, "income": 1200000, "loan_amount": 400000,
    "loan_term": 36, "cibil_score": 780, "debt_to_income_ratio": 0.22,
    "monthly_income": 100000, "approx_monthly_installment": 11666.67,
    "high_dependents_flag": 0, "gender": "Male", "education": "Graduate",
    "employment_status": "Salaried", "housing_type": "Owned",
    "area_type": "Urban", "loan_intent": "HOME",
}

REJECT_LEANING = {
    "age": 45, "dependents": 4, "income": 300000, "loan_amount": 900000,
    "loan_term": 84, "cibil_score": 480, "debt_to_income_ratio": 1.10,
    "monthly_income": 25000, "approx_monthly_installment": 12000,
    "high_dependents_flag": 1, "gender": "Female", "education": "Not Graduate",
    "employment_status": "Unemployed", "housing_type": "Rented",
    "area_type": "Rural", "loan_intent": "DEBTCONSOLIDATION",
}


def test_root_ok(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_health_model_loaded(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "healthy"
    assert body["model_loaded"] is True


def test_predict_approve_leaning_applicant(client):
    resp = client.post("/predict", json=APPROVE_LEANING)
    assert resp.status_code == 200
    body = resp.json()
    assert body["loan_status"] in ("Approved", "Rejected")
    assert 0.0 <= body["approval_probability"] <= 1.0
    assert round(body["approval_probability"] + body["rejection_probability"], 4) == 1.0


def test_predict_reject_leaning_applicant(client):
    resp = client.post("/predict", json=REJECT_LEANING)
    assert resp.status_code == 200
    body = resp.json()
    assert body["loan_status"] in ("Approved", "Rejected")


def test_predict_invalid_payload_returns_422(client):
    bad = dict(APPROVE_LEANING)
    bad["age"] = "not-a-number"
    resp = client.post("/predict", json=bad)
    assert resp.status_code == 422


def test_predict_missing_field_returns_422(client):
    incomplete = {"age": 30}
    resp = client.post("/predict", json=incomplete)
    assert resp.status_code == 422


def test_predict_out_of_range_cibil_returns_422(client):
    bad = dict(APPROVE_LEANING)
    bad["cibil_score"] = 950  # above the 900 ceiling
    resp = client.post("/predict", json=bad)
    assert resp.status_code == 422
